﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos1
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            Random random = new Random();

            int inicio = Convert.ToInt32(txtInicio.Text);
            int fim = Convert.ToInt32(txtFim.Text);
            int sorteio = random.Next(inicio, fim);

            MessageBox.Show(sorteio.ToString());
        }
    }
}
