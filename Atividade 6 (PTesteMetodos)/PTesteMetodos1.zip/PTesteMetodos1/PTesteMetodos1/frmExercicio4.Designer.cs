﻿namespace PTesteMetodos1
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtPalavra = new System.Windows.Forms.RichTextBox();
            this.btnNum = new System.Windows.Forms.Button();
            this.btnPosicao = new System.Windows.Forms.Button();
            this.btnAlfabeticos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtPalavra
            // 
            this.rchtxtPalavra.Location = new System.Drawing.Point(124, 43);
            this.rchtxtPalavra.Name = "rchtxtPalavra";
            this.rchtxtPalavra.Size = new System.Drawing.Size(421, 135);
            this.rchtxtPalavra.TabIndex = 0;
            this.rchtxtPalavra.Text = "";
            // 
            // btnNum
            // 
            this.btnNum.Location = new System.Drawing.Point(124, 202);
            this.btnNum.Name = "btnNum";
            this.btnNum.Size = new System.Drawing.Size(138, 46);
            this.btnNum.TabIndex = 1;
            this.btnNum.Text = "Numéricos";
            this.btnNum.UseVisualStyleBackColor = true;
            this.btnNum.Click += new System.EventHandler(this.btnNum_Click);
            // 
            // btnPosicao
            // 
            this.btnPosicao.Location = new System.Drawing.Point(263, 202);
            this.btnPosicao.Name = "btnPosicao";
            this.btnPosicao.Size = new System.Drawing.Size(138, 46);
            this.btnPosicao.TabIndex = 2;
            this.btnPosicao.Text = "1ª Posição em branco";
            this.btnPosicao.UseVisualStyleBackColor = true;
            this.btnPosicao.Click += new System.EventHandler(this.btnPosicao_Click);
            // 
            // btnAlfabeticos
            // 
            this.btnAlfabeticos.Location = new System.Drawing.Point(407, 201);
            this.btnAlfabeticos.Name = "btnAlfabeticos";
            this.btnAlfabeticos.Size = new System.Drawing.Size(138, 47);
            this.btnAlfabeticos.TabIndex = 3;
            this.btnAlfabeticos.Text = "Alfabéticos";
            this.btnAlfabeticos.UseVisualStyleBackColor = true;
            this.btnAlfabeticos.Click += new System.EventHandler(this.btnAlfabeticos_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(722, 328);
            this.Controls.Add(this.btnAlfabeticos);
            this.Controls.Add(this.btnPosicao);
            this.Controls.Add(this.btnNum);
            this.Controls.Add(this.rchtxtPalavra);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtPalavra;
        private System.Windows.Forms.Button btnNum;
        private System.Windows.Forms.Button btnPosicao;
        private System.Windows.Forms.Button btnAlfabeticos;
    }
}