﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos1
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNum_Click(object sender, EventArgs e)
        {
            int n = 0;

        for (int i = 0; i<rchtxtPalavra.Text.Length; i++)   
            if (char.IsNumber(rchtxtPalavra.Text, i))
                n ++;

            MessageBox.Show(n.ToString());
        }

        private void btnPosicao_Click(object sender, EventArgs e)
        {
            int n = 0;

            while (char.IsWhiteSpace(rchtxtPalavra.Text, n) == false)
                n++;

            MessageBox.Show(n.ToString());
        }

        private void btnAlfabeticos_Click(object sender, EventArgs e)
        {
            int n = 0;

            foreach (char c in rchtxtPalavra.Text)
                if (char.IsLetter(rchtxtPalavra.Text, n))
                    n++;

            MessageBox.Show(n.ToString());
        }
    }
}
