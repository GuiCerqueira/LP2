﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            string[,] respostas = new string[1, 10];
            string[] gabarito = { "A", "B", "C", "D", "E", "B", "A", "C", "A", "E" };
            int x, y;
            string auxiliar;

            for (x = 0; x < 1; x++)
            {
                for (y = 0; y < 10; y++)
                {
                    auxiliar = Interaction.InputBox("Digite a resposta correta " + (y + 1));
                    if ((auxiliar != "A") && (auxiliar != "B") && (auxiliar != "C") && (auxiliar != "D") && (auxiliar != "E"))
                    {
                        MessageBox.Show("Resposta inválida");
                        y -= 1;
                    }
                    else
                    {
                        respostas[x, y] = auxiliar;
                    }
                }
            }
            for (x = 0; x < 1; x++)
            {
                for (y = 0; y < 10; y++)
                    if (respostas[x,y] == gabarito [y])
                {
                    lstbxComparativo.Items.Add("O aluno acertou a questão " + (y+1) + ": Resposta do aluno: " + respostas[x, y] + " / Respostas correta: " + gabarito[y]);
                }
                else
                    {
                        lstbxComparativo.Items.Add("O aluno errou a questão " + (y + 1) + ": Resposta do aluno: " + respostas[x, y] + " / Respostas correta: " + gabarito[y]);
                    }
            }
        }
    }
}







