﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVerifica = new System.Windows.Forms.Button();
            this.lstbxComparativo = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnVerifica
            // 
            this.btnVerifica.Location = new System.Drawing.Point(12, 12);
            this.btnVerifica.Name = "btnVerifica";
            this.btnVerifica.Size = new System.Drawing.Size(197, 70);
            this.btnVerifica.TabIndex = 0;
            this.btnVerifica.Text = "Verificar";
            this.btnVerifica.UseVisualStyleBackColor = true;
            this.btnVerifica.Click += new System.EventHandler(this.btnVerifica_Click);
            // 
            // lstbxComparativo
            // 
            this.lstbxComparativo.FormattingEnabled = true;
            this.lstbxComparativo.Items.AddRange(new object[] {
            " "});
            this.lstbxComparativo.Location = new System.Drawing.Point(216, 13);
            this.lstbxComparativo.Name = "lstbxComparativo";
            this.lstbxComparativo.Size = new System.Drawing.Size(660, 290);
            this.lstbxComparativo.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(888, 335);
            this.Controls.Add(this.lstbxComparativo);
            this.Controls.Add(this.btnVerifica);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnVerifica;
        private System.Windows.Forms.ListBox lstbxComparativo;
    }
}

