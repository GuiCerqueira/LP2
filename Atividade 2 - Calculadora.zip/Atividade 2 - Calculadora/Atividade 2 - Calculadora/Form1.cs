﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_2___Calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void buttonSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonSoma_Click(object sender, EventArgs e)
        {
            double Num1, Num2;

            if (!double.TryParse(textBox1.Text, out Num1))
            {
                MessageBox.Show("Número inválido!");
                textBox1.Focus();
            }
            else
                if (!double.TryParse(textBox2.Text, out Num2))
            {
                MessageBox.Show("Número inválido!");
                textBox2.Focus();
            }
            else
            {
                double resultado;

                resultado = Num1 + Num2;
                textBoxResult.Text = resultado.ToString("N2");
            }
        }

        private void buttonSub_Click(object sender, EventArgs e)
        {
            double Num1, Num2;

            if (!double.TryParse(textBox1.Text, out Num1))
            {
                MessageBox.Show("Número inválido!");
                textBox1.Focus();
            }
            else
                if (!double.TryParse(textBox2.Text, out Num2))
            {
                MessageBox.Show("Número inválido!");
                textBox2.Focus();
            }
            else
            {
                double resultado;

                resultado = Num1 - Num2;
                textBoxResult.Text = resultado.ToString("N2");
            }
        }

        private void buttonMult_Click(object sender, EventArgs e)
        {
            double Num1, Num2;

            if (!double.TryParse(textBox1.Text, out Num1))
            {
                MessageBox.Show("Número inválido!");
                textBox1.Focus();
            }
            else
                if (!double.TryParse(textBox2.Text, out Num2))
            {
                MessageBox.Show("Número inválido!");
                textBox2.Focus();
            }
            else
            {
                double resultado;

                resultado = Num1 * Num2;
                textBoxResult.Text = resultado.ToString("N2");
            }
        }

        private void buttonDiv_Click(object sender, EventArgs e)
        {
            double Num1, Num2;

            if (!double.TryParse(textBox1.Text, out Num1))
            {
                MessageBox.Show("Número inválido!");
                textBox1.Focus();
            }
            else
                if (!double.TryParse(textBox2.Text, out Num2))
            {
                MessageBox.Show("Número inválido!");
                textBox2.Focus();
            }
            else
                if (Num2 == 0)
            {
                MessageBox.Show("O divisor deve ser diferente de 0");
                textBox2.Focus();
            }
            else
            {
                double resultado;

                resultado = Num1 / Num2;
                textBoxResult.Text = resultado.ToString("N2");
            }
        }

        private void buttonLimp_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBoxResult.Clear();
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            double Num1;

            if (!double.TryParse(textBox1.Text, out Num1))
                MessageBox.Show("Número inválido!");
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            double Num2;

            if (!double.TryParse(textBox2.Text, out Num2))
                MessageBox.Show("Número inválido!");
        }
    }
}
