﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_3___IMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();  
            txtPeso.Clear();
            txtIMC.Clear(); 
        }
        private void txtAltura_Validated(object sender, EventArgs e)
        {
            double Num1;

            if (!Double.TryParse(txtAltura.Text, out Num1))
                MessageBox.Show("Altura inválida!");

            if (Num1 == 0)
                MessageBox.Show("Altura deve ser maior que 0!");
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            double Num2;

            if (!Double.TryParse(txtPeso.Text, out Num2))
                MessageBox.Show("Peso inválido!");

            if (Num2 == 0)
                MessageBox.Show("Peso deve ser maior que 0!");
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double Num1, Num2;

            if (!Double.TryParse(txtAltura.Text, out Num1))
            {
                MessageBox.Show("Altura inválida!");
                txtAltura.Focus();
            }
            else
            if (Num1 == 0)
            {
                MessageBox.Show("Altura deve ser maior que 0!");
                txtAltura.Focus();
            }
            else
            if (!Double.TryParse(txtPeso.Text, out Num2))
            {
                MessageBox.Show("Peso inválido!");
                txtPeso.Focus();
            }
            else
            if (Num2 == 0)
            {
                MessageBox.Show("Peso deve ser maior que 0!");
                txtPeso.Focus();
            }
            else
            {
                double imc;

                imc = Num2 / (Num1 * Num1);
                imc = Math.Round(imc, 1);
                txtIMC.Text = imc.ToString("N1");

            if (imc< 18.5)
                MessageBox.Show("IMC: Magreza");
            else
            if ((imc >= 18.5) && (imc <= 24.9))
                    MessageBox.Show("IMC: Normal");
            else
             if ((imc >= 25) && (imc <= 29.9))
                    MessageBox.Show("IMC: Sobrepeso");
            else
             if ((imc >= 30) && (imc <= 39.9))
                    MessageBox.Show("IMC: Obesidade");
            else
                    MessageBox.Show("IMC: Obesidade grave");
            }
        }
    }
}
