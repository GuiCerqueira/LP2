﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_4___Triângulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            double Num1;

            if (!Double.TryParse(txtNum1.Text, out Num1))
                MessageBox.Show("Número inválido!");
        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            double Num2;

            if (!Double.TryParse(txtNum1.Text, out Num2))
                MessageBox.Show("Número inválido!");
        }

        private void txtNum3_Validated(object sender, EventArgs e)
        {
            double Num3;

            if (!Double.TryParse(txtNum1.Text, out Num3))
                MessageBox.Show("Número inválido!");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtNum3.Clear();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double Num1, Num2, Num3;

            if (!Double.TryParse(txtNum1.Text, out Num1))
            {
                MessageBox.Show("Número inválido!");
                txtNum1.Focus();
            }
            else
            if (!Double.TryParse(txtNum2.Text, out Num2))
            {
                MessageBox.Show("Número inválido!");
                txtNum2.Focus();
            }
            else
            if (!Double.TryParse(txtNum3.Text, out Num3))
            {
                MessageBox.Show("Número inválido!");
                txtNum3.Focus();
            }

            else
            if ((Num1 < Num2 + Num3) && (Num1 > Num2 - Num3) && (Num2 < Num1 + Num3)
                && (Num2 > Num1 - Num3) && (Num3 < Num1 + Num2) && (Num3 > Num1 - Num2))
            {
                if ((Num1 == Num2) && (Num2 == Num3))
                    MessageBox.Show("Triângulo equilátero!");
                else
                if ((Num1 != Num2) && (Num2 != Num3) && (Num3 != Num1))
                    MessageBox.Show("Triângulo escaleno!");
                else
                    MessageBox.Show("Triângulo isósceles!");
            }

            else
                MessageBox.Show("Não é possível fazer um triângulo!");
        }
    }
}
